package com.acm.tallerfinal.dtos;

import lombok.Data;

@Data
public class CategoriaDTO {
    private Integer idCategoria;
    private String nombre;
}