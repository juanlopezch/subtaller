package com.acm.tallerfinal.dtos;

import lombok.Data;

@Data
public class DepartamentoDTO {
    private Integer idDepartamento;
    private String nombre;
}